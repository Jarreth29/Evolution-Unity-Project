using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SettingsMenu : MonoBehaviour
{
    [Header("Size Selection Buttons")]
    public Button smallButton;
    public Button mediumButton;
    public Button largeButton;

    [Header("Action Buttons")]
    public Button applyButton;
    public Button backButton;

    [Header("Changes Applied")]
    public TextMeshProUGUI changesAppliedText;
    public float changesAppliedDuration = 2f; // Duration to show the changes applied message

    [Header("World Sizes")]
    // Uncomment the following lines if you want to use a struct for world size presets
    //private WorldSizePreset presetSmall = new WorldSizePreset(WorldSizeEnum.SMALL, 50f);
    //private WorldSizePreset presetMedium = new WorldSizePreset(WorldSizeEnum.MEDIUM, 100f);
    //private WorldSizePreset presetLarge = new WorldSizePreset(WorldSizeEnum.LARGE, 200f);
    //private WorldSizePreset currentSelectedPreset;
    private Vector2 smallWorldSize = new Vector2(50f, 50f);
    private Vector2 mediumWorldSize = new Vector2(100f, 100f);
    private Vector2 largeWorldSize = new Vector2(200f, 200f);
    private Vector2 selectedWorldSize;

    [Header("Settings Controllers")]
    [SerializeField] private FoodSettingsController foodSettingsController;
    [SerializeField] private OrganismSettingsController organismSettingsController;

    void Start()
    {
        float saveWith = PlayerPrefs.GetFloat("WorldWidth", mediumWorldSize.x);
        float saveHeight = PlayerPrefs.GetFloat("WorldHeight", mediumWorldSize.y);
        selectedWorldSize = new Vector2(saveWith, saveHeight);

        // Uncomment the following line to set the default selected preset to medium size when using struct
        //currentSelectedPreset = presetMedium; // Default to medium size
        UpdateButtonStates();

        smallButton.onClick.AddListener(() => SelectSize(smallWorldSize));
        mediumButton.onClick.AddListener(() => SelectSize(mediumWorldSize));
        largeButton.onClick.AddListener(() => SelectSize(largeWorldSize));
        applyButton.onClick.AddListener(ApplySettings);
        backButton.onClick.AddListener(BackButton);

        if (changesAppliedText != null)
        {
            changesAppliedText.gameObject.SetActive(false);
        }
    }

    private void SelectSize(Vector2 size)
    {
        selectedWorldSize = size;
        // Uncomment the following line if you want to use a struct for world size presets
        //currentSelectedPreset = selected;
        UpdateMinsMaxs();
        UpdateButtonStates();
    }

    private void UpdateMinsMaxs()
    {
        foodSettingsController.UpdateMinsAndMaxs(selectedWorldSize.x);
    }

    private void UpdateButtonStates()
    {
        // Commented code is for the potential implementation using WorldSizePreset enum
        //smallButton.interactable = (currentSelectedPreset.worldSizeName != WorldSizeEnum.SMALL);
        //mediumButton.interactable = (currentSelectedPreset.worldSizeName != WorldSizeEnum.MEDIUM);
        //largeButton.interactable = (currentSelectedPreset.worldSizeName != WorldSizeEnum.LARGE);

        smallButton.interactable = (selectedWorldSize != smallWorldSize);
        mediumButton.interactable = (selectedWorldSize != mediumWorldSize);
        largeButton.interactable = (selectedWorldSize != largeWorldSize);
    }

    private void ApplySettings()
    {
        PlayerPrefs.SetFloat("WorldWidth", selectedWorldSize.x);
        PlayerPrefs.SetFloat("WorldHeight", selectedWorldSize.y);
        PlayerPrefs.Save();
        foodSettingsController.SaveSettings();
        organismSettingsController.SaveSettings();
        Debug.Log($"OptionsMenu-> World SizeX: {selectedWorldSize.x}, World SizeY: {selectedWorldSize.y}");
        ShowStatusMessage("Changes Applied", Color.green);
    }

    private void BackButton()
    {
        SceneManager.LoadScene("MainMenuScene");
    }

    private void ShowStatusMessage(string message, Color textColor)
    {
        if (changesAppliedText != null)
        {
            changesAppliedText.text = message;
            changesAppliedText.color = textColor;
            changesAppliedText.gameObject.SetActive(true);
            StartCoroutine(HiddenMessageAfterDelay(changesAppliedDuration));
        }
        else
        {
            Debug.LogWarning("Changes Applied Text is not assigned in the inspector.");
        }
    }

    private IEnumerator HiddenMessageAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        if (changesAppliedText != null)
        {
            changesAppliedText.gameObject.SetActive(false);
        }
    }
}
