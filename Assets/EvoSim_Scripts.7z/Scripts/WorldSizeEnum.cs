public enum WorldSizeEnum

{
    SMALL,
    MEDIUM,
    LARGE
}
